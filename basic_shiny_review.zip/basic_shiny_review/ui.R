ui <- fluidPage(
  h1("Guess the Pass Code"),
  textInput(inputId = "guess_text",
            label = "Input a phrase and see if it's the word:"),
  textOutput(outputId = "response_text")
)