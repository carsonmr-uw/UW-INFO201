server <- function(input, output){
  output$response_text <- renderText({
    code <- "open sesame"
    if (input$guess_text == code){return("correct")}
    else {return("incorrect")}
  })
}